import id from 'firebase-auto-ids';

class MyCustomEvent {
  /**
   * @param {String} type
   * @param {Object.<string, Object>} eventInitDict
   */
  constructor(type, eventInitDict = {}) {
    this.type = type;
    this.detail = eventInitDict.detail || null;
  }
}

/******** EVENT IDENTIFIERS ********/
/**
 * @readonly
 * @enum {string}
 */
export const Events = Object.freeze({
  APP_INITIALIZED: 'evt.app.app_initialized',
  GEOLOCATION_UPDATED: 'evt.geo.location_updated',
  DATABASE_CONNECTED: 'evt.database.database_client_connected',
  INTENT_IDENTIFIED: 'evt.intents.intent_identified', 
  INTENT_SPEC_GENERATED: 'evt.intents.intent_specification_generated',
  INTENT_REPLY_RECEIVED: 'evt.intents.intent_reply_message_received',
  INTENT_REQUEST_CAPTURED: 'evt.intents.intent_request_captured',
  COMPLETION_RESPONSE_RECEIVED: 'evt.completions.completion_response_received',
  COMPLETION_AUDIO_UPLOADED: 'evt.completions.completion_audio_uploaded',
  INCOMING_AUDIO_DETECTED: 'evt.speech.incoming_audio_detected',
  INCOMING_REQUEST_AUDIO_CAPTURED: 'evt.intents.incoming_request_audio_captured',
});

/**
 *
 */
export class SystemEvent {
  header = {
    id: id(Date.now()),
    timestamp: new Date().toISOString(),
    meta: { _open: {} },
    name: null,
  };
  payload;

  /**
   * @param {String} name
   * @param {Object.<string, Object>} payload
   * @param {Object.<string, Object>} metadata
   */
  constructor(name, payload = {}, metadata = {}) {
    this.header.meta._open = { ...metadata };
    this.header.name = name;
    this.payload = payload;

    return new MyCustomEvent(name, {
      detail: this,
    });
  }

  /**
   * @returns {Object}
   */
  toJSON() {
    return {
      header: this.header,
      payload: this.payload
    }
  }
}


