/******** EXPO DEPENDENCIES ********/
import * as FileSystem from 'expo-file-system';

/******** LOCAL DEPENDENCIES ********/
import { config } from '../../config';
import { IEvent, ISandbox } from '../interfaces';
import { SystemEvent, Events } from '../events';

export class IntentService {
  #logger;
  #sandbox;
  #EVENT_SOURCE = 'com.valet.services.intent_service'; 

  /**
   * @param {ISandbox} sandbox
   */
  constructor(sandbox) {
    this.#sandbox = sandbox;
    this.#logger = sandbox.core.logger.getLoggerInstance();
  }

  /**
   * @param {IEvent<Object>} event
   */
  async onIntentReplyMessageReceived(event) {
    console.log(event);
    
    try {
      const userMessage = {
        role: 'user',
        content: JSON.stringify(event.payload)
      }

      // TODO: how do we get the User data ??
      // I think it comes from the event

      const message = await this.#sandbox.my.LLMService.getCompletion({ 
        systemMessage: config.completions.intentReply.system,
        assistantMessage: config.completions.intentReply.assistant,
        userMessage
      });

      this.#sandbox.dispatchEvent(new SystemEvent(Events.COMPLETION_RESPONSE_RECEIVED, 
        { text: message }, 
        { 
          source: this.#EVENT_SOURCE,
          reply_id: event.payload.reply_id,
          user_id: event.payload.payload.context.user.id,
          rel: 'intent_reply', 
        }
      ));
    } catch(ex) {
      this.#logger.error(`INTERNAL_ERROR (${this.#EVENT_SOURCE}): Exception during fetch of completion message. See details -> ${ex.message}`);
    }
  }

  /**
   * Parses the text of the user's request to establish the user's intent
   * @param {Object} requestConfig
   * @param {String} requestConfig.text
   * @param {String} requestConfig.user_id
   * @param {String} requestConfig.reply_id
   * @returns {Object}
   */
  async #captureRequestIntent(requestConfig) {
    const { text, user_id, reply_id } = requestConfig;
    const userMessage = {
      role: 'user',
      content: text
    };

    const message = await this.#sandbox.my.LLMService.getCompletion({ 
      systemMessage: config.completions.intentParse.system,
      assistantMessage: config.completions.intentParse.assistant,
      userMessage
    });

    const intentCompletionContent = JSON.parse(message);
    const intentMessage = await this.#sandbox.my.ContextService.getClientContext({ 
      intent: intentCompletionContent.intent, 
      content: { 
        ...intentCompletionContent.meta, 
        reply_id,
      } 
    }); 
    const { acknowledgementText } = intentCompletionContent;

    // We play the acknowledgement text before continuing the intent processing
    this.#sandbox.dispatchEvent(new SystemEvent(Events.COMPLETION_RESPONSE_RECEIVED, 
      { text: acknowledgementText }, 
      { 
        user_id,
        reply_id,
        rel: 'intent_acknowledgement',
        source: this.#EVENT_SOURCE 
      }
    ));

    return intentMessage;
  }

  /**
   * @param {Object} intentMessage
   * @param {String} reply_id
   */
  async #pushIntentRequest(intentMessage, reply_id) {

    try {
      const event = new SystemEvent(Events.INTENT_SPEC_GENERATED, 
        { ...intentMessage }, 
        { reply_id, version: '0.0.1' }
      );
      
      const client = this.#sandbox.my.DataAccessLayer.getDbClient();

      const { error } = await client
      .from('intent_messages')
      .insert(event.detail);

      if (error) {
        this.#logger.error(`INTERNAL_ERROR (${this.#EVENT_SOURCE}): Could not commit intent specification to database. See details ->`, error.message);
        return;
      }

      this.#sandbox.dispatchEvent(event);

    } catch(ex) {
      this.#logger.error(`INTERNAL_ERROR (${this.#EVENT_SOURCE}): Could not push intent specification. See details ->`, ex.message);
    }         
  }

  /**
   * Fires when user speech recording is finished; converts user speech to text. This is the 
   * first stage of specifying user intent
   * @param {Object} event
   * See https://community.openai.com/t/sending-blob-to-whisper-api-in-react-native/708672 for details on the below implementation
   */
  async onIncomingUserRequestAudioCaptured(event) {
    console.log(event);
    try {
      // maybe get the user data here??
      const { localFileURL, user_id } = event.payload

      const response = await FileSystem.uploadAsync('https://api.openai.com/v1/audio/transcriptions',
        localFileURL,
        {
          headers: {
            Authorization: `Bearer ${config.keys.OPENAI_KEY}`,
          },
          httpMethod: 'POST',
          uploadType: FileSystem.FileSystemUploadType.MULTIPART,
          fieldName: 'file', 
          mimeType: 'audio/mpeg',
          parameters: {
            model: 'whisper-1',
          },
        }
      );
      const { text } = JSON.parse(response.body);

      const reply_id = this.#sandbox.core.generateUUID();
      const requestIntent = await this.#captureRequestIntent({ text, user_id, reply_id });
      this.#pushIntentRequest(requestIntent, reply_id);

    } catch(ex) {
      console.error(`INTERNAL_ERROR (${this.#EVENT_SOURCE}): Could not get audio transcription. See details ->`, ex);
    }
  }
}