/******** LOCAL DEPENDENCIES ********/
import { IEvent, ISandbox } from '../interfaces';
import { SystemEvent, Events } from '../events';

export class UserService {
  #sandbox;
  
  /**
   * @param {ISandbox} sandbox
   */
  constructor(sandbox) {
    this.#sandbox = sandbox;
  }

  /**
   * @returns {Object} 
   */
  async getCurrentUser() {
    return {
      displayName: 'Sean',
      user_id: 'ef69db02-2338-47d0-b989-59b73d2298ab'
    }
  }
}
