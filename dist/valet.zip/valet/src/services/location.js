/******** EXPO DEPENDENCIES ********/
import * as Location from 'expo-location';

/******** LOCAL DEPENDENCIES ********/
import { SystemEvent, Events } from '../events';

export class LocationService {
  #sandbox;

  constructor(sandbox) {
    this.#sandbox = sandbox;
  }

  /**
   * 
   * @returns {Object}
   */
  async getCurrentLocation() {
    const { coords: { latitude, longitude } } = await Location.getCurrentPositionAsync({});
    this.#sandbox.dispatchEvent(new SystemEvent(Events.GEOLOCATION_UPDATED), { longitude, latitude });

    return {
      latitude,
      longitude
    }
  }  
}
