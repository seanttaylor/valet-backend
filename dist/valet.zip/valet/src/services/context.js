/******** LOCAL DEPENDENCIES ********/
import { ISandbox, IIntentSpecification } from '../interfaces';

const ContextProvider = {
  /**
   * Returns an intent specification for the get ride use case
   * @param {Object} metadata
   * @returns {IIntentSpecification}
   */
  'app.intents.mobility.get_ride': async function(metadata) {
    const location = await this.sandbox.my.LocationService.getCurrentLocation();
    const user = await this.sandbox.my.UserService.getCurrentUser();
    
    return {
      context: {
        location: {
          current: {
            address: null,
            bookmarked: false,
            lat: location.latitude,
            lng: location.longitude,
            name: null
          },
          destination: {
            address: null,
            bookmarked: false,
            lat: metadata.lat,
            lng: metadata.lng,
            name: metadata.destinationName,
          },
        },
        user: {
          displayName: user.displayName,
          id: user.user_id,
        },
      },
      domain: 'app.intents.mobility.get_ride',
      reply_id: metadata.reply_id
    }
  }
};


export class ContextService {
  #ContextProvider = ContextProvider;
  #sandbox;

  /**
   * @param {ISandbox} sandbox
   */
  constructor(sandbox) {
    this.#sandbox = sandbox;
  }

  /**
   * Builds a client context object containing all relevant data to 
   * complete a request in specified domain
   * @param {Object} config 
   * @returns {Object}
   */
  async getClientContext(config) {
    // We use call here to provide access to the sandbox methods to `ContextProvider`    
    const result = await this.#ContextProvider[config.intent].call({ sandbox: this.#sandbox }, config.content);
    return result;
  }
}

