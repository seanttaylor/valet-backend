/******** EXPO DEPENDENCIES ********/
import { Audio } from 'expo-av';
//import * as FileSystem from 'expo-file-system';

/******** LOCAL DEPENDENCIES ********/
import { IEvent, ISandbox } from '../interfaces';
import { SystemEvent, Events } from '../events';

/******** UTILITIES ********/
import { Buffer } from 'buffer';
import { decode as base64Decode, encode as base64Encode } from 'base64-arraybuffer';

export class PlaybackService {
  #EVENT_SOURCE = 'com.valet.services.playback';
  #logger;
  #sandbox;

  /**
   * @param {ISandbox} sandbox
   */
  constructor(sandbox) {
    this.#sandbox = sandbox;
    this.#logger = sandbox.core.logger.getLoggerInstance();
  }

  /**
   * Fires when a completion that requires playback is available
   * @param {IEvent<Object>} event
   */
  async onCompletionAudioUploaded(event) {
    this.#logger.log(event);

    try {
      const filePath = event.payload.path;
      const client = this.#sandbox.my.DataAccessLayer.getDbClient();

      const { data } = client
      .storage
      .from('completion_audio')
      .getPublicUrl(filePath);

      const { publicUrl } = data;
      await Audio.setAudioModeAsync({ playsInSilentModeIOS: true });

     // console.log({ publicUrl })
      const { sound } = await Audio.Sound.createAsync(
        { uri: publicUrl },
        { shouldPlay: true }
      );

      await sound.playAsync();
    } catch(ex) {
      this.#logger.error('INTERNAL_ERROR: Could not play completion audio', ex.message);
    }
  }

  /**
   * Fires when user speech recording is finished; this is the 
   * first stage of specifying user intent
   * @param {IEvent<Object>} event
   * See https://community.openai.com/t/sending-blob-to-whisper-api-in-react-native/708672 for details on the below implementation
   */
  // async onIncomingUserRequestAudioCaptured(event) {
  //   this.#logger.log(event);
  //   try {
  //     const { localFileURL, user_id, rel } = event.payload

  //     const response = await FileSystem.uploadAsync('https://api.openai.com/v1/audio/transcriptions',
  //       localFileURL,
  //       {
  //         headers: {
  //           Authorization: `Bearer ${config.keys.OPENAI_KEY}`,
  //         },
  //         httpMethod: 'POST',
  //         uploadType: FileSystem.FileSystemUploadType.MULTIPART,
  //         fieldName: 'file', 
  //         mimeType: 'audio/mpeg',
  //         parameters: {
  //           model: 'whisper-1',
  //         },
  //       }
  //     );
  //     const { text } = JSON.parse(response.body);
  //     this.#sandbox.dispatchEvent(new SystemEvent(Events.INTENT_REQUEST_CAPTURED, { text, user_id }, { rel, source: this.#EVENT_SOURCE }));

  //   } catch(ex) {
  //     this.#logger.error(`INTERNAL_ERROR: Could not get audio transcription. See details ->`, ex.message);
  //   }
  // }

  /**
   * Fires when a completion is returned from the LLM; creates
   * audio from the LLM's text response; uploads audio to Supabase
   * @param {IEvent<Object>} event
   */
  async onCompletionResponseReceived(event) {
    this.#logger.log(event);
    const { reply_id, user_id, rel } = event.header.meta._open;
    
    // trigger ElevenLabs TTS API to render completion text as speech  

    try {
      // const audio1 = await elevenlabs.generate({
      //   voice: "Rachel",
      //   text: "Hello! 你好! Hola! नमस्ते! Bonjour! こんにちは! مرحبا! 안녕하세요! Ciao! Cześć! Привіт! வணக்கம்!",
      //   model_id: "eleven_multilingual_v2"
      // });

      // console.log({ audio1 });
      // console.log(typeof(audio1));
      
      const audio = await this.#sandbox.my.LLMService.generateTTSAudio(event.payload.text);
      const client = this.#sandbox.my.DataAccessLayer.getDbClient();
      
      const fileURL = `${user_id}/${rel}/${reply_id}/completion-${new Date().toISOString()}.mp3`;
      const buffer = Buffer.from(await audio.arrayBuffer());
      const bufferBase64 = buffer.toString('base64');
      const arrayBuffer = base64Decode(bufferBase64);
      
      const { data, error } = await client
        .storage
        .from('completion_audio')
        .upload(fileURL, arrayBuffer, {
          contentType: 'audio/mpeg'
        });

      if (error) {
        this.#logger.error('INTERNAL_ERROR: Could not upload audio. See details ->', error.message);
        return; 
      }

      this.#sandbox.dispatchEvent(new SystemEvent(Events.COMPLETION_AUDIO_UPLOADED, { ...data }, { rel: 'completion_response', source: this.#EVENT_SOURCE }));   
    } catch(ex) {
      this.#logger.error(`INTERNAL_ERROR: (${this.#EVENT_SOURCE}) Exception during text-to-speech capture. See details -> `, ex.message);
    }
  }
}