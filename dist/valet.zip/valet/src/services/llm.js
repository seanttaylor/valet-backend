import OpenAI from 'openai';

/******** LOCAL DEPENDENCIES ********/
import { ISandbox } from '../interfaces';
import { config } from '../../config';

const openai = new OpenAI({
  apiKey: config.keys.OPENAI_KEY
});

export class LLMService {
  #EVENT_SOURCE = 'com.valet.service.llm';
  #sandbox;
  #logger;

  /**
   * @param {ISandbox} sandbox
   */
  constructor(sandbox) {
    this.#sandbox = sandbox;
    this.#logger = sandbox.core.logger.getLoggerInstance();
  }

  /**
   * Makes a completion request to a large language model
   * @param {Object} config
   * @param {String} config.systemMessage
   * @param {String} config.userMessage
   * @param {String} config.assistantMessage
   * @returns {String}
   */
  async getCompletion(config) {        
    const message = await openai.chat.completions.create({
      messages: [config.systemMessage, config.userMessage, config.assistantMessage],
      model: 'gpt-4o-mini',
    });
    
    return message.choices[0].message.content;
  }

  /**
   * Createa an audio file from a text input
   * @param {String} text
   * @return {Object}
   */
  async generateTTSAudio(text) {
    try {
    const audio = await openai.audio.speech.create({
      model: 'tts-1',
      voice: 'alloy',
      input: text,
    });

    return audio;
    } catch(ex) {
      this.#logger.error(`INTERNAL_ERROR: (${this.#EVENT_SOURCE}) Could not generate TTS Audio. See details ->`, ex.message);
    }
  }
}