export const testIntentMessage = {
  created_at: '2024-08-22T02:24:16.723558+00:00',
  header: {
    id: '7124b2f0-b41c-46f4-98ae-a2107af104cc',
    name: 'evt.intents.specification_generated',
    timestamp: '2024-08-17T20:01:58.832Z',
    version: '0.0.1',
  },
  id: '4a16ccce-f232-432f-9521-93dadcf27f87',
  payload: {
    context: {
      location: {
        current: {
          address: null,
          bookmarked: false,
          lat: '37.7752315',
          lng: '-122.418075',
          name: null,
        },
        destination: {
          address: null,
          bookmarked: false,
          lat: '<LAT>',
          lng: '<LNG>',
          name: 'AMC Empire 25',
        },
      },
      user: {
        displayName: 'Veruca',
        id: 'a3d9ccd9-57f2-4ba8-aad1-b7fe8f731ac9',
      },
    },
    domain: 'app.intents.mobility.get_ride',
    reply_id: '028d95e2-1706-4944-a05b-e6eaa9b1b4c0',
  },
};

/**
 * Generates a stub intent reply message from the backend; this
 * signifies that an intent message has been pushed to the backend, that
 * the backend has already specified the intent to the frontend and
 * the frontend has sent an intent message with all relevant metadata to
 * the backend
 * @param {Object} config
 * @param {String} config.reply_id
 * @param {String} config.destinationName
 * @param {String} config.userDisplayName
 * @param {String} config.user_id
 */
export const getIntentReplyMessage = (config) => ({
  created_at: '2024-08-24T00:11:01.432662+00:00',
  id: '4d780e2d-07af-4427-b528-c3d3295dba80',
  payload: {
    context: {
      location: {
        current: {
          address: null,
          bookmarked: false,
          lat: '72.1115',
          lng: '90.9538',
          name: null,
        },
        destination: {
          address: null,
          bookmarked: false,
          lat: '31.9065',
          lng: '87.6805',
          name: config.destinationName,
        },
      },
      user: {
        displayName: config.userDisplayName,
        id: config.user_id,
      },
    },
    domain: 'app.intents.mobility.get_ride',
    name: 'app.use_cases.strategy.UBER',
    reply_id: config.reply_id,
    result: {
      fare: {
        currency_code: 'USD',
        display: '$4.32',
        expires_at: 1477285210,
        fare_id:
          'd67b07577b3c86fd23e483d50c84e5152e550b6abb03cece4fc3793c0c068f2e',
        value: 4.32,
      },
      pickup_estimate: 4,
      trip: {
        distance_estimate: 2.39,
        distance_unit: 'mile',
        duration_estimate: 600,
      },
    },
  },
  reply_id: config.reply_id
  // Obviously the reply_id will be the same as that of the incoming intent message
  //reply_id: '903496b2-b3f2-4f70-8574-16ae38403550',
});

/**
 * @param {Object} config
 * @param {String} config.userDisplayName 
 * @param {String} config.destinationName
 */
export const getCompletionMessage = (config) => ({
  "id": "chatcmpl-9zoY4A18z4KqCKEFyKzXxd53uIZr2",
  "object": "chat.completion",
  "created": 1724519344,
  "model": "gpt-4o-mini-2024-07-18",
  "choices": [
      {
          "index": 0,
          "message": {
              "role": "assistant",
              "content": `"\"Hi ${config.userDisplayName}, your Uber to ${config.destinationName} is estimated to cost $18.32. The car should arrive in about 14 minutes, and the trip will cover approximately 10.39 miles, taking about 20 minutes.\""`,
              "refusal": null
          },
          "logprobs": null,
          "finish_reason": "stop"
      }
  ],
  "usage": {
      "prompt_tokens": 1055,
      "completion_tokens": 49,
      "total_tokens": 1104
  },
  "system_fingerprint": "fp_507c9469a1"
})
