export const config = {
  completions: {
    intentReply: {
      system: {
        role: 'system',
        content: [{
          text: "Your role as a language model is to assist users by interpreting responses from a ride-sharing service API. Each response, referred to as an 'intent reply message,' contains detailed information about a user's ride request. You will receive structured data encapsulating the result of the request, which includes fare details, pickup estimates, and trip estimates, along with the destination name and user information. Your task is to extract this information, understand its significance, and generate a clear, concise message to the user that summarizes the outcome of their ride request. This will help users understand what to expect from their booking, including how much the ride will cost, how long before the ride arrives, and how long the trip will take. Each response you generate should be straightforward and user-friendly, aimed at enhancing the user's experience by providing them with timely and relevant information about their requested service. Below are a set of example inputs and the expected outputs indicated by ```.  In every case you will interpret these inputs and provide a summary for the user: Sometimes the shape of the input object will change but you will *ALWAYS* find the relevant information under the `result` key.\n\n```\nExpected input: { 'result': { 'fare': { 'display': '$4.32' }, 'pickup_estimate': 4, 'trip': { 'distance_estimate': 2.39, 'duration_estimate': 600 } }, 'context': { 'location': { 'destination': { 'name': 'AMC Empire 25' } }, 'user': { 'displayName': 'Augustus' } } }\n\n Expected Output: “Hi Augustus, your Uber to AMC Empire 25 is estimated to cost $4.32. The car should arrive in about 4 minutes, and the trip will cover approximately 2.39 miles, taking about 10 minutes.\"\n```\n\n```\nExpected Input: { 'result': { 'fare': { 'display': '$10.50' }, 'pickup_estimate': 2, 'trip': { 'distance_estimate': 5.5, 'duration_estimate': 900 } }, 'context': { 'location': { 'destination': { 'name': 'Central Park' } }, 'user': { 'displayName': 'Julia’,   'id': ‘59ef97ab-d8bc-4293-b7fa-0f12ffb55bdc’ } } }\"   \n\nExpected Output: ”Hi Julia, your Uber to Central Park is estimated to cost $10.50. The car should arrive in about 2 minutes, and the trip will cover approximately 5.5 miles, taking about 15 minutes.\"\n```",
          type: 'text'
        }],
      },
      assistant: {
        role: 'assistant',
        content: [{
          type: 'text',
          text: '"Hi Jean Claude, your Uber to AMC Empire 25 is estimated to cost $18.32. The car should arrive in about 14 minutes, and the trip will cover approximately 10.39 miles, taking about 20 minutes."',
        }],
      },
    },
    intentParse: {
    system: {
      role: 'system',
      content: [{
        text: "As an AI language model, your role is to assist users by interpreting their requests for ride-sharing services and extracting key details from their inputs to generate structured intent replies. Users might express their need for transportation in various ways, and it is your task to identify the intent as 'app.intents.mobility.get_ride' and extract pertinent information such as the destination name or address from their statements. When a destination name is mentioned without an address, set the address to null, and vice versa. Each response should not only include the identified intent and metadata about the ride request but also an affirmative acknowledgement text that varies and maintains a casual and breezy tone and VARIES with each request. Acknowledgment text MUST be different for each request. Below are examples of user inputs and the expected JSON outputs that you should generate based on these inputs, including the new field 'acknowledgementText'.\n\nExample 1:\nUser Input: 'Hey, I need a ride to AMC Empire 25.'\nExpected Output: {\n  \"intent\": \"app.intents.mobility.get_ride\",\n  \"meta\": {\n    \"destinationName\": \"AMC Empire 25\",\n    \"address\": null\n  },\n  \"acknowledgementText\": \"Sure thing, I'll run that down for you!\"\n}\n\nExample 2:\nUser Input: 'I need a car to AMC Empire 25.'\nExpected Output: {\n  \"intent\": \"app.intents.mobility.get_ride\",\n  \"meta\": {\n    \"destinationName\": \"AMC Empire 25\",\n    \"address\": null\n  },\n  \"acknowledgementText\": \"Alright, checking that for you now!\"\n}\n\nExample 3:\nUser Input: 'Can you get me an Uber to 161 West 81st Street?'\nExpected Output: {\n  \"intent\": \"app.intents.mobility.get_ride\",\n  \"meta\": {\n    \"destinationName\": null,\n    \"address\": \"161 West 81st Street\"\n  },\n  \"acknowledgementText\": \"On it, I’ll find you a ride to 161 West 81st Street.\"\n}",
        type: 'text'
      }]
    },
    assistant: {
      role: 'assistant',
      content: [{
        text: 'Sure thing, let me look into that for you!',
        type: 'text'
    }]
  } 
}

  },
  keys: {
    ELEVENLABS_API_KEY: 'sk_0488ab001ebfab3f9ef4de27e7aeefcfe2768244fb608d00',
    OPENAI_KEY: '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',
    SUPABASE_PUBLIC_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR0Y3Nua2luemJtYXhvY2FuYW9hIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjQwMDE4MDgsImV4cCI6MjAzOTU3NzgwOH0.eXCbj4yKnAwyMrtWWNwiIe4XQPjjEF1r3qWipCzGYqM'
  },
  vars: {
    SUPABASE_URL: 'https://ttcsnkinzbmaxocanaoa.supabase.co'
  },
  subscriptions: {
    completed_strategy_executions: {
      event: 'INSERT',
      schema: 'public',
      table: 'completed_strategy_executions',
      channel: 'outbound_intent_reply_messages',
    }
  },
  misc: {
    model: 'gpt-4o-mini'
  }
}