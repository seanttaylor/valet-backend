import { Text, SafeAreaView, StyleSheet, Button } from 'react-native';
import { useState, useEffect } from 'react';
import { ElevenLabsClient, play } from 'elevenlabs';

/******** EXPO DEPENDENCIES ********/
import { Audio } from 'expo-av';
import * as Location from 'expo-location';

/******** UTILITIES ********/
import { Buffer } from 'buffer';
import { decode as base64Decode, encode as base64Encode } from 'base64-arraybuffer';
import { once } from './src/utils/once';

/******** LOCAL DEPENDENCIES ********/
import { config } from './config';

import { Sandbox } from './src/sandbox';
import { SystemEvent, Events } from './src/events.js';
import { IEvent, ISandbox } from './src/interfaces';

import { IntentService } from './src/services/intent';
import { DataAccessLayer } from './src/services/database';
import { LLMService } from './src/services/llm';
import { PlaybackService } from './src/services/playback';

import { ContextService } from './src/services/context';
import { LocationService } from './src/services/location';
import { UserService } from './src/services/user';

const EVENT_SOURCE = 'com.valet.sandbox';

/******** MODULE REGISTRATION ********/
Sandbox.modules.of('DataAccessLayer', DataAccessLayer);
Sandbox.modules.of('IntentService', IntentService);
Sandbox.modules.of('LLMService', LLMService);
Sandbox.modules.of('PlaybackService', PlaybackService);

Sandbox.modules.of('LocationService', LocationService);
Sandbox.modules.of('ContextService', ContextService);
Sandbox.modules.of('UserService', UserService);

// const elevenlabs = new ElevenLabsClient({
//   apiKey: config.keys.ELEVENLABS_API_KEY
// });

const mySandbox = new Sandbox(['IntentService', 'PlaybackService', 'LLMService', 'DataAccessLayer', 'ContextService', 'LocationService', 'UserService'], 
  /**
   * @param {ISandbox} box
   */
  async function(box) {
    const logger = box.core.logger.getLoggerInstance();

    /******** EVENT REGISTRATION ********/
    box.addEventListener(Events.APP_INITIALIZED, ({ detail: event })=> once(onAppInitialization)(event));
    box.addEventListener(Events.DATABASE_CONNECTED, ({ detail: event })=> logger.log(event));
    box.addEventListener(Events.INCOMING_AUDIO_DETECTED, ({ detail: event })=> logger.log(event));
    box.addEventListener(Events.INTENT_SPEC_GENERATED, ({ detail: event })=> logger.log(event));
    
    box.addEventListener(Events.INTENT_REPLY_RECEIVED, ({ detail: event })=> box.my.IntentService.onIntentReplyMessageReceived(event));
    box.addEventListener(Events.INCOMING_REQUEST_AUDIO_CAPTURED, ({ detail: event })=> box.my.IntentService.onIncomingUserRequestAudioCaptured(event));
    
    box.addEventListener(Events.COMPLETION_RESPONSE_RECEIVED, ({ detail: event })=> box.my.PlaybackService.onCompletionResponseReceived(event));
    box.addEventListener(Events.COMPLETION_AUDIO_UPLOADED, ({ detail: event })=> box.my.PlaybackService.onCompletionAudioUploaded(event));

    /**
     * @param {IEvent<Object>} event
     */
    function onAppInitialization(event) {
      logger.log(event);
      
      const client = box.my.DataAccessLayer.getDbClient();

      client
      .channel(config.subscriptions.completed_strategy_executions.channel)
      .on(
        'postgres_changes',
        config.subscriptions.completed_strategy_executions,
        (payload) => mySandbox.dispatchEvent(new SystemEvent(Events.INTENT_REPLY_RECEIVED, payload.new, { source: EVENT_SOURCE }))
      )
      .subscribe();
    }
  }
);
  

export default function App() {

  /******** HOOKS ********/
  const [ recording, setRecording ] = useState();
  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [ permissionResponse, requestPermission ] = Audio.usePermissions();

  async function startRecording() {
    try {
      mySandbox.dispatchEvent(new SystemEvent(Events.INCOMING_AUDIO_DETECTED, {}, { source: 'com.valet.components.App' }));

      if (permissionResponse.status !== 'granted') {
        await requestPermission();
      }

      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
      });
     
      const { recording } = await Audio.Recording.createAsync(Audio.RecordingOptionsPresets.HIGH_QUALITY);
      setRecording(recording);
   
    } catch (ex) {
      console.error(`INTERNAL_ERROR (${EVENT_SOURCE}): Could not record audio. See details ->`, ex.message);
    }
  }

  /**
   * 
   */
  async function stopRecording() {
    setRecording(undefined);

    await recording.stopAndUnloadAsync();
    await Audio.setAudioModeAsync(
      {
        allowsRecordingIOS: false,
      }
    );
    const uri = recording.getURI();
    mySandbox.dispatchEvent(new SystemEvent(Events.INCOMING_REQUEST_AUDIO_CAPTURED, { 
          localFileURL: uri,
          // TODO: Where is the user id coming from?
          user_id: 'ef69db02-2338-47d0-b989-59b73d2298ab',
        }, 
        {  
          rel: 'intent_requests', 
          source:'com.valet.components.App' 
        }
      )
    );
  }
  
  /**
   * 
   */
  function onLoad() {
    mySandbox.dispatchEvent(new SystemEvent(Events.APP_INITIALIZED, {}, { source: 'com.valet.components.App' })); 
  }

  useEffect(() => {
    onLoad();

    (async() => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setErrorMsg('Permission to access location was denied');
        console.error('INTERNAL_ERROR: Permission to access location denied');
        return;
      }
      
    })();
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <Button
        title={recording ? 'Stop Recording' : 'Start Recording'}
        onPress={recording ? stopRecording : startRecording}
        color="#841584"
      />
      <Text style={styles.paragraph}>{ errorMsg ? errorMsg : undefined }</Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
